import sys

from PyQt5 import QtWidgets

from ViewModels.MainWindowViewModel import MainWindowViewModel


def main():
    app = QtWidgets.QApplication(sys.argv)

    mainWindow = MainWindowViewModel()
    mainWindow.show()

    app.exec_()


if __name__ == "__main__":
    main()
