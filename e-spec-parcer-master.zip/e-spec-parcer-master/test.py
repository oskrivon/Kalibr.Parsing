import os
from utilities import *

files = os.listdir("data_test")

for file in files:
    if ".xlsv" in file or ".xls" in file:
        print("data_test/" + file)
        df = pd.read_excel("data_test/" + file)
        test_spec = Specification(df)
        test_spec.save_parsed_grouped('parsed/parsed_' + file)
