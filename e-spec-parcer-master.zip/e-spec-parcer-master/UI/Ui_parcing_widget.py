# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/alez-m/Documents/PythonProjects/e-spec-parcer/UI/parcing_widget.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(764, 613)
        self.verticalLayout = QtWidgets.QVBoxLayout(Form)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label = QtWidgets.QLabel(Form)
        self.label.setObjectName("label")
        self.verticalLayout_3.addWidget(self.label)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.originalTablePath = QtWidgets.QLineEdit(Form)
        self.originalTablePath.setReadOnly(True)
        self.originalTablePath.setObjectName("originalTablePath")
        self.horizontalLayout_3.addWidget(self.originalTablePath)
        self.openTableButton = QtWidgets.QPushButton(Form)
        self.openTableButton.setObjectName("openTableButton")
        self.horizontalLayout_3.addWidget(self.openTableButton)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.originalTableView = QtWidgets.QTableView(Form)
        self.originalTableView.setObjectName("originalTableView")
        self.verticalLayout_3.addWidget(self.originalTableView)
        self.parceButton = QtWidgets.QPushButton(Form)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.parceButton.sizePolicy().hasHeightForWidth())
        self.parceButton.setSizePolicy(sizePolicy)
        self.parceButton.setObjectName("parceButton")
        self.verticalLayout_3.addWidget(self.parceButton)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        self.line = QtWidgets.QFrame(Form)
        self.line.setFrameShape(QtWidgets.QFrame.VLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.horizontalLayout.addWidget(self.line)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)
        self.parcedTableView = QtWidgets.QTableView(Form)
        self.parcedTableView.setObjectName("parcedTableView")
        self.verticalLayout_4.addWidget(self.parcedTableView)
        self.saveTableButton = QtWidgets.QPushButton(Form)
        self.saveTableButton.setObjectName("saveTableButton")
        self.verticalLayout_4.addWidget(self.saveTableButton)
        self.horizontalLayout.addLayout(self.verticalLayout_4)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "Исходная таблица"))
        self.openTableButton.setText(_translate("Form", "Открыть..."))
        self.parceButton.setText(_translate("Form", "Распарсить"))
        self.label_2.setText(_translate("Form", "Распаршенная таблица"))
        self.saveTableButton.setText(_translate("Form", "Сохранить"))

