import inject
from Views.MainWindowView import MainWindowView


class MainWindowPresenter(object):
    @inject.autoparams()
    def __init__(self, view: MainWindowView):
        self.view = view
        self.view.show()
