import json
import string
import re

from pprint import pprint
import pandas as pd
import numpy as np

from utilities.helpers import *

output_columns = [
    "Component_type",
    "Name",
    "Capacity",
    "Resistance",
    "Inductance",
    "Voltage",
    # "Frequency",
    "Tolerance",
    "Body",
    "Quantity",
]


class Specification:
    def __init__(self, data, rows_to_skip=0, columns_to_work_with=None):

        self.data = data
        self.parsed_data = pd.DataFrame(columns=[col for col in output_columns])
        self.warnings = []
        self.conformity = {col: None for col in output_columns}
        self.make_conformity()

    def make_conformity(self):
        columns = {}
        for col in self.data.columns:
            for key, value in indefecators.items():
                reason = is_this_column_(self.data[col], key)
                if reason > 0:
                    if key not in columns:
                        columns[key] = []
                    columns[key].append((col, reason))

        for col in self.data.columns:
            reason = is_quantity(self.data[col])
            if reason > 0:
                if "Quantity" not in columns:
                    columns["Quantity"] = []
                columns["Quantity"].append((col, reason))

        pprint(columns)
        for col in columns:
            columns[col] = sorted(columns[col], key=lambda x: x[1], reverse=True)
            self.conformity[col] = [columns[col][0][0]]

    def change_conformity(self, input_col: str, output_col: str):
        self.conformity[output_col] = [input_col]

    def return_parsed(self):
        if len(self.parsed_data) == 0:
            self.parse()
        return self.parsed_data()

    def parse(self):
        for i in range(len(self.data)):
            # print(f"Now parse {i}")
            self.parse_item(i)
        self.parsed_data.Quantity = self.parsed_data.Quantity.fillna(0)
        self.parsed_data = self.parsed_data.fillna("-")

    def parse_item(self, i):
        current_row = self.data.iloc[i]
        parsed_row = {}
        for col in list(set(output_columns) - set(["Component_type", "Name"])):
            if self.conformity[col] is not None:
                value = get_value(current_row, self.conformity[col][0], col)
                if value is not None:
                    parsed_row[col] = value

        name = ""
        for part in current_row:
            if part is not np.nan:
                name += str(part) + " "

        # if everything is none get all in name
        # if len(parsed_row) == 0:
        #    parsed_row["Name"] = name[:-1]

        special_name = maybe_this_is_special_board(name)
        if special_name is not None:
            for key in list(set(output_columns) - set(["Body"])):
                if key in parsed_row:
                    parsed_row["Name"] = name
                    self.warnings.append(parsed_row)
            body = None
            if "Body" in parsed_row:
                body = parsed_row["Body"]
            parsed_row = {}
            parsed_row["Name"] = special_name
            if body is not None:
                parsed_row["Body"] = body

        # check type
        parsed_row["Component_type"] = check_type(parsed_row)
        if parsed_row["Component_type"] == "Unkown type":
            parsed_row["Name"] = name[:-1]

        if self.conformity["Quantity"] is not None:
            # Здесь превращать в int
            parsed_row["Quantity"] = toInt(current_row[self.conformity["Quantity"][0]])
        else:
            parsed_row["Quantity"] = 1
            
        if "Tolerance" in parsed_row:
            parsed_row["Tolerance"] = procent_to_fractal(parsed_row["Tolerance"])
            
        self.parsed_data = self.parsed_data.append(parsed_row, ignore_index=True)

    def save_parsed(self, name=None):
        if len(self.parsed_data) == 0:
            self.parse()
        if name is None:
            name = "parsed_Specification.xlsx"
        self.parsed_data.Quantity = self.parsed_data.Quantity.fillna(0)
        with pd.ExcelWriter(name) as writer:
            self.parsed_data.fillna("-").to_excel(
                writer, sheet_name="Parsed", merge_cells=False
            )
            self.data.to_excel(writer, sheet_name="Input table", merge_cells=False)

    def save_parsed_grouped(self, name=None):
        if len(self.parsed_data) == 0:
            self.parse()
        if name is None:
            name = "parsed_groped_Specification.xlsx"
        self.parsed_data.Quantity = self.parsed_data.Quantity.fillna(0)
        with pd.ExcelWriter(name) as writer:
            self.parsed_data.fillna("-").groupby(
                list(set(output_columns) - set(["Quantity"]))
            )["Quantity"].sum().to_excel(writer, sheet_name="Parsed", merge_cells=False)
            self.data.to_excel(writer, sheet_name="Input table", merge_cells=False)


def union(specifications):
    d = pd.concat(specifications)
    d.Quantity = d.Quantity.fillna(0)
    return pd.DataFrame(
        d.fillna("-")
        .groupby(list(set(output_columns) - set(["Quantity"])))["Quantity"]
        .sum()
    )


def substract(specifications, store):
    estimate = pd.merge(
        specifications,
        store,
        on=list(set(output_columns) - set(["Quantity"])),
        how="left",
        suffixes=("_specification", "_in_stock"),
    ).fillna(0)

    estimate["Quantity"] = estimate.Quantity_specification - estimate.Quantity_in_stock
    estimate = estimate.drop(columns=["Quantity_specification", "Quantity_in_stock"])
    return estimate.loc[estimate["Quantity"] > 0]


def make_purchase(spec_data, stores):
    spec_union = pd.DataFrame(columns=[col for col in output_columns])
    store_union = pd.DataFrame(columns=[col for col in output_columns])

    sps = [(spec.copy(), n) for spec, n in spec_data]

    for sp, num in sps:
        sp["Quantity"] = sp.Quantity.astype(int) * num
    spec_union = union([sp for sp, _ in sps])

    if len(stores) > 0:
        store_union = union([store for store in stores])
        spec_union = substract(spec_union, store_union)
    
    return spec_union


def save_df(df, name):
    with pd.ExcelWriter(name) as writer:
        df.fillna("-").groupby(list(set(output_columns) - set(["Quantity"])))[
            "Quantity"
        ].sum().to_excel(writer, merge_cells=False)
