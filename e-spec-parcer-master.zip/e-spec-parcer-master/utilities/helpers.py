import sys
import os
import json
import string
import re

from pprint import pprint
import pandas as pd
import numpy as np


numbers = "0123456789"


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
        base_path = os.path.abspath(os.path.join(sys.executable, ".."))
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


def toInt(instring):
    instring = str(instring)
    answer = ""
    for letter in instring:
        if letter in numbers:
            answer += letter
    return int(answer) if len(answer) > 0 and int(answer) < 100000 else None


with open(resource_path("utilities/Identifiers.json"), "r") as read_file:
    indefecators = json.load(read_file)
orders = indefecators["Order"]
redable = indefecators["Redable"]
indefecators = indefecators["Identifiers"]

def is_this_column_(column, column_name):
    column_indefecator = indefecators[column_name]
    counter = 0
    for item in column:
        item = str(item)
        for indefecator in column_indefecator:
            search_pattern = (
                f"\d+\s*{indefecator}"
                if column_name not in ["Tolerance", "Body"]
                else indefecator
            )
            if re.search(search_pattern, item) is not None:
                counter += 1
    return counter


def to_normal_order(cell, out_column_name):
    colum_order = orders[out_column_name]
    for order in colum_order:
        for order_pattern in colum_order[order]:
            search_pattern = f"\d+\s?{order_pattern}"
            founded = re.search(search_pattern, cell)
            if founded is not None:
                return float(re.search("\d+(\,|\.)?\d*", cell.replace(",",".")).group()) * float(order)
    return cell
    raise "Error"


def get_value(row, in_column_name, out_column_name):
    if in_column_name is None:
        return None
    if out_column_name == "Quantity":
        return None
    cell = str(row[in_column_name])
    column_indefecator = indefecators[out_column_name]
    for indefecator in column_indefecator:
        search_pattern = (
            f" \d*(\d.)?\d+\s*{indefecator}\s"
            if out_column_name not in ["Tolerance", "Body"]
            else indefecator
        )
        founded = re.search(search_pattern," " + cell + " ")
        if founded is not None:
            if out_column_name in ["Capacity", "Resistance", "Inductance"]:
                return to_redable(out_column_name, to_normal_order(founded.group(), out_column_name))
            return founded.group()
    return None


def is_order_number(row):
    i = int(len(row) / 2)
    if (
        str(row[i]).isnumeric()
        and str(row[i + 1]).isnumeric()
        and str(row[i - 1]).isnumeric()
    ):
        if (int(row[i]) - int(row[i - 1])) * (int(row[i + 1]) - int(row[i])) == 1:
            return True
    return False


def is_quantity(row):
    counter = 0
    for i in row:
        i = str(i)
        if i.isnumeric() and int(float(i)) < 101:
            counter += 1
    return (not is_order_number(row)) * counter


def check_type(data):
    if ("Capacity" in data) and ("Tolerance" in data) and ("Body" in data):
        return "Capacitor"
    if ("Resistance" in data) and ("Body" in data):
        return "Resistor"
    if ("Inductance" in data) and ("Body" in data):
        return "Oscillator"
    if "Name" in data:
        if maybe_this_is_special_board(data["Name"]) is not None:
            return "Other"
    return "Unkown type"


with open(resource_path("utilities/Chips.json"), "r") as read_file:
    chips = json.load(read_file)["Other"]


def maybe_this_is_special_board(name):
    for ch in chips:
        if ch in name:
            return ch
    return None

def to_dnt(instring):
    instring = str(instring)
    answer = ""
    for letter in instring:
        if letter in numbers:
            answer += letter
    return float(answer) if len(answer) > 0 and float(answer) <= 100 else None

def procent_to_fractal(s):
    if type(s) != str:
        return s
    if "%" in s:
        return f"{to_dnt(s)/100}"
    return s

def to_redable(row_name, cell):
    if cell == "-":
        return cell
    num, word = redable[row_name]
    return f"{round(float(cell)/num,ndigits=5)} {word}"
