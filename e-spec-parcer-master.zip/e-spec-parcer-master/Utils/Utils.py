from PyQt5 import QtWidgets


def browseFile(self, name):
    fileName = QtWidgets.QFileDialog.getOpenFileName(
        self, name, filter="Table (*.xlsx *.xls)")
    return fileName[0]


def saveFile(self, name):
    fileName = QtWidgets.QFileDialog.getSaveFileName(
        self, "Сохранить", name, filter="Table (*.xlsx)")
    return fileName[0]
