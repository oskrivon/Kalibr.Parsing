import inject

from Views.MainWindowView import MainWindowView
from Presenters.MainWindowPresenter import MainWindowPresenter


class AppContext(object):
    @staticmethod
    def Initialize():
        # Binding
        inject.configure(AppContext.BindMainWindow)

        # Injecting
        inject.instance(MainWindowPresenter)

    @staticmethod
    def BindMainWindow(binder: inject.Binder):
        binder.bind(MainWindowView, MainWindowView())
        binder.bind_to_constructor(
            MainWindowPresenter, lambda: MainWindowPresenter())
