import os
import pandas as pd

from PyQt5 import QtWidgets
import UI.Ui_main as Ui_main

# Windows
from ViewModels.PurchaseViewModel import PurchaseViewModel
from ViewModels.ParcingViewModel import ParcingViewModel


class MainWindowViewModel(QtWidgets.QMainWindow, Ui_main.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.puchaseButton.clicked.connect(self.openPurchase)
        self.parcingButton.clicked.connect(self.openParcing)

    def openPurchase(self):
        self.purchaseView = PurchaseViewModel()
        self.purchaseView.show()

    def openParcing(self):
        self.parcingView = ParcingViewModel()
        self.parcingView.show()
