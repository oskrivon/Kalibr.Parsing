import os
import pandas as pd

import Utils.Utils as utils

from PyQt5 import QtWidgets, QtCore
import UI.Ui_parcing_widget as Ui_parcing_widget
from Extentions.PandasTableModel import PandasTableModel

from utilities import *


class ParcingViewModel(QtWidgets.QWidget, Ui_parcing_widget.Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.spec = None
        self.specPath = None

        self.openTableButton.clicked.connect(self.openTable)
        self.parceButton.clicked.connect(self.parceTable)
        self.saveTableButton.clicked.connect(self.saveParsed)

    def openTable(self):
        path = utils.browseFile(self, "Выберите спецификацию")
        if not path:
            return
        self.specPath = path

        self.originalTablePath.setText(path)

        dataFrame = pd.read_excel(path)
        self.spec = Specification(dataFrame)
        model = PandasTableModel(self.spec.data)
        self.originalTableView.setModel(model)
        self.parcedTableView.setModel(None)

    def parceTable(self):
        if not self.spec:
            return

        self.spec.parse()
        model = PandasTableModel(self.spec.parsed_data)
        self.parcedTableView.setModel(model)

    def saveParsed(self):
        if (not self.spec) or (len(self.spec.parsed_data) == 0):
            return

        path = utils.saveFile(self, os.path.basename(self.specPath))
        self.spec.save_parsed_grouped(path)
