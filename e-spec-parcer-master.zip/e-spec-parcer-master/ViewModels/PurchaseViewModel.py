import os
import pandas as pd

from PyQt5 import QtWidgets, QtCore

import Utils.Utils as utils
import UI.Ui_purchase_2 as Ui_purchase
import UI.Ui_specListItem as Ui_specListItem
from Extentions.PandasTableModel import PandasTableModel

from utilities import *


class SpecListItem(QtWidgets.QWidget, Ui_specListItem.Ui_Form):
    def __init__(self, parent=None, name=None):
        super(SpecListItem, self).__init__(parent)
        self.setupUi(self)
        self.name.setText(name)


class PurchaseViewModel(QtWidgets.QWidget, Ui_purchase.Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.manufacture = None
        self.storage = None

        self.openStorageButton.clicked.connect(self.openStorage)
        self.openManufactureButton.clicked.connect(self.openManufacture)

        self.addSpecButton.clicked.connect(self.addSpec)
        self.exportButton.clicked.connect(self.exportPurchase)

        # Specs list view
        self.listWidget.selectionModel().selectionChanged.connect(
            self.specListSelectionChanged)
        self.RemoveSpecButton.clicked.connect(self.removeSpec)

# Base
    def openStorage(self):
        path = utils.browseFile(self, "Выберите таблицу склада")
        if not path:
            return
        self.storagePath.setText(path)

        self.storage = pd.read_excel(path)
        model = PandasTableModel(self.storage)
        self.storageTable.setModel(model)

    def openManufacture(self):
        path = utils.browseFile(self, "Выберите таблицу склада")
        if not path:
            return
        self.manufacturePath.setText(path)

        self.manufacture = pd.read_excel(path)
        model = PandasTableModel(self.manufacture)
        self.manufactureTable.setModel(model)

# Specs
    def addSpec(self):
        path = utils.browseFile(self, "Выберите спецификацию")
        if not path:
            return
        item = QtWidgets.QListWidgetItem(self.listWidget)
        itemWidget = SpecListItem(name=os.path.basename(path))
        item.setSizeHint(itemWidget.sizeHint())
        item.setData(100, path)
        itemWidget.count.valueChanged.connect(
            lambda: (item.setData(101, itemWidget.count.value()),
                     print(os.path.basename(path), " -> ", itemWidget.count.value()))
        )

        self.listWidget.addItem(item)
        self.listWidget.setItemWidget(item, itemWidget)

    def removeSpec(self):
        for itemIndex in self.listWidget.selectedIndexes():
            self.listWidget.takeItem(itemIndex.row())

    def specListSelectionChanged(self):
        selected = self.listWidget.selectedItems()
        if len(selected) == 0:
            return

        path = self.listWidget.selectedItems()[0].data(100)
        if not path:
            return
        self.spec = pd.read_excel(path)
        model = PandasTableModel(self.spec)
        self.specTable.setModel(model)

# Other
    def exportPurchase(self):
        path = utils.saveFile(self, "Закупка")
        if not path:
            return

        specs = [(
            pd.read_excel(self.listWidget.item(i).data(100)),
            self.listWidget.item(i).data(101)
        ) for i in range(self.listWidget.count())]

        stock = []
        if not self.storage is None:
            stock.append(self.storage)
        if not self.manufacture is None:
            stock.append(self.manufacture)

        if len(stock) < 1 or len(specs) == 0:
            return

        export = make_purchase(specs, [self.storage, self.manufacture])

        save_df(export, path)
