import os
import pandas as pd

from PyQt5 import QtWidgets, QtCore
from Extentions.PandasTableModel import PandasTableModel
import UI.Ui_main as Ui_main


class MainWindowView(QtWidgets.QMainWindow, Ui_main.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.actionOpen.triggered.connect(self.browseFile)

    def browseFile(self):
        fileName = QtWidgets.QFileDialog.getOpenFileName(
            self, "Выберите папку", filter="Table (*.xlsx *.xls)")

        if not fileName:
            return

        with open(fileName[0], 'rb') as file:
            dataFrame = pd.read_excel(file)
            model = PandasTableModel(dataFrame)
            self.originalTableView.setModel(model)
